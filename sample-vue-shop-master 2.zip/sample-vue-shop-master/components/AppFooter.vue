<template>
  <footer>
    Made with 🎸 from <a href="https://twitter.com/sarah_edo" target="_blank">sarah_edo</a>. This project is open source, visit <a href="https://github.com/sdras/sample-vue-shop" target="_blank">the repo.</a>
  </footer>
</template>

<style scoped>
footer {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  background: black;
  color: white;
  text-align: center;
  letter-spacing: 0.03em;
  margin-top: 10px;
  width: 100%;
  height: 50px;
}

a,
a:visited,
a:active {
  color: white;
  font-weight: bold;
  text-decoration: none;
  padding-left: 6px;
}
</style>